SimpleAudio Library

Original Author: Ralph Niemitz
Maintainer: Jack Meng

Description:
This extension of the original library was made so some
experiences could be added to the original in order to 
grow upon what the original author has layed down.

The modifications made are questionable for individual need,
and should be up to you to either use as is or modify
it based on the needs.

LICENSE: This is and will always be licensed under the MIT-License 
by the original author.

Notice: I, Jack, in no way is affiliated with the original author,
and is simply "improving" upon the original.
